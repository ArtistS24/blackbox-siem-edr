#!/bin/bash

file=$(find "$HOME" -type f -path "*/EDR/core/Main.sh" 2>/dev/null)
sudo bash $file
